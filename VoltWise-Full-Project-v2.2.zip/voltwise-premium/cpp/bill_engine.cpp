#include <emscripten/bind.h>
#include <algorithm>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

using namespace emscripten;

// Abstract base class: common billing behaviour for all connection categories.
class ElectricityCalculator {
private:
    double fixedCharge;
    double subsidyRate;
    double taxRate;
    std::vector<double> slabLimits;
    std::vector<double> slabRates;

protected:
    double calculateEnergy(double units) const {
        double remaining = units, previousLimit = 0, amount = 0;
        for (size_t i = 0; i < slabLimits.size(); ++i) {
            const double inSlab = std::max(0.0, std::min(remaining, slabLimits[i] - previousLimit));
            amount += inSlab * slabRates[i];
            remaining -= inSlab;
            previousLimit = slabLimits[i];
            if (remaining <= 0) break;
        }
        return amount;
    }
    double getFixedCharge() const { return fixedCharge; }
    double getSubsidyRate() const { return subsidyRate; }
    double getTaxRate() const { return taxRate; }

public:
    ElectricityCalculator(double fixed, double subsidy, double tax,
                          std::vector<double> limits, std::vector<double> rates)
        : fixedCharge(fixed), subsidyRate(subsidy), taxRate(tax),
          slabLimits(std::move(limits)), slabRates(std::move(rates)) {}
    virtual ~ElectricityCalculator() = default;
    virtual std::string connectionName() const = 0;

    virtual val calculate(double units) const {
        if (units < 0 || units > 100000) throw std::invalid_argument("Units must be between 0 and 100000.");
        const double energy = calculateEnergy(units);
        const double subsidy = energy * getSubsidyRate();
        const double tax = (energy + getFixedCharge() - subsidy) * getTaxRate();
        val out = val::object();
        out.set("energy", energy);
        out.set("fixed", getFixedCharge());
        out.set("subsidy", subsidy);
        out.set("tax", tax);
        out.set("total", std::max(0.0, energy + getFixedCharge() - subsidy + tax));
        out.set("connection", connectionName());
        return out;
    }
};

class DomesticCalculator : public ElectricityCalculator {
public:
    DomesticCalculator(double fixed, double subsidy, double tax,
                       std::vector<double> limits, std::vector<double> rates)
        : ElectricityCalculator(fixed, subsidy, tax, std::move(limits), std::move(rates)) {}
    std::string connectionName() const override { return "Domestic"; }
};

class CommercialCalculator : public ElectricityCalculator {
public:
    CommercialCalculator(double fixed, double tax,
                         std::vector<double> limits, std::vector<double> rates)
        : ElectricityCalculator(fixed, 0.0, tax, std::move(limits), std::move(rates)) {}
    std::string connectionName() const override { return "Commercial"; }
};

class BillEngine {
public:
    val calculate(double units, const std::string& region, const std::string& type) const {
        if (units < 0 || units > 100000) throw std::invalid_argument("Invalid unit value.");
        const std::vector<double> limits{100, 200, 400, std::numeric_limits<double>::infinity()};
        double fixed = 40, subsidy = .10, tax = .05;
        std::vector<double> rates{2, 3, 4.5, 6.5};
        if (region == "Haryana") {
            fixed = type == "commercial" ? 120 : 50; subsidy = type == "commercial" ? 0 : .05;
            rates = type == "commercial" ? std::vector<double>{6,7,8,9} : std::vector<double>{2.5,3.5,5,7};
        } else if (region == "Mumbai") {
            fixed = type == "commercial" ? 150 : 60; subsidy = type == "commercial" ? 0 : .05; tax = .08;
            rates = type == "commercial" ? std::vector<double>{6.5,7.5,8.5,9.5} : std::vector<double>{3,4,5.5,7.5};
        } else if (region == "Delhi") {
            fixed = type == "commercial" ? 100 : 40; subsidy = type == "commercial" ? 0 : .10;
            rates = type == "commercial" ? std::vector<double>{5.5,6.5,7.5,8.5} : std::vector<double>{2,3,4.5,6.5};
        } else throw std::invalid_argument("Unknown region.");

        std::unique_ptr<ElectricityCalculator> calculator;
        if (type == "commercial")
            calculator = std::make_unique<CommercialCalculator>(fixed, region == "Mumbai" ? .10 : .08, limits, rates);
        else
            calculator = std::make_unique<DomesticCalculator>(fixed, subsidy, tax, limits, rates);
        return calculator->calculate(units);
    }
};

EMSCRIPTEN_BINDINGS(voltwise_module) {
    class_<BillEngine>("BillEngine")
        .constructor<>()
        .function("calculate", &BillEngine::calculate);
}
